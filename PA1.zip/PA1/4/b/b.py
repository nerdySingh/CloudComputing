import os,time

def getfileName(dirname):
    filesize = 1
    time_towrite =0.5
    start= time.time()
    filename= os.path.join(dirname,'Test.txt')
    count =0
    while True:
        try:
            data = "This is PA1 assignment of Cloud Computing CS-553. "
            counter = int(1000000*filesize/len(data))
            try:
                f = open(filename,"w")
            except:
                raise
            for i in range(0,counter):
                f.write(data)
            f.close()
            os.remove(filename)
        except:
            raise
        count+=1
        difference = time.time()-start
        if difference > time_towrite:
            break
    return ((count*filesize)/difference)                

    

if __name__ =="__main__":
    dirname = os.getcwd()
    val=getfileName(dirname)
    print("Disk writing speed for 1 MegaByte of file in seconds is {:.2f}".format(val))
